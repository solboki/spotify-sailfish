<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="fr_FR">
<context>
    <name />
    <message id="components-ph-search">
        <location filename="../qml/components/MySearchField.qml" line="63" />
        <source>Search</source>
        <extracomment>Placeholder text of SearchField</extracomment>
        <translation>Recherche</translation>
    </message>
</context>
<context>
    <name>About</name>
    <message>
        <location filename="../qml/pages/About.qml" line="20" />
        <source>About</source>
        <translation>À propos</translation>
    </message>
    <message>
        <location filename="../qml/pages/About.qml" line="55" />
        <source>Spotify controller for Sailfish OS</source>
        <translation>Télécommande Spotify pour Sailfish OS</translation>
    </message>
    <message>
        <location filename="../qml/pages/About.qml" line="65" />
        <source>Copyright (C) 2019</source>
        <extracomment>I doubt this needs to be translated</extracomment>
        <translation>Copyright (C) 2019</translation>
    </message>
    <message>
        <location filename="../qml/pages/About.qml" line="73" />
        <source>License: MIT</source>
        <translation>Licence : MIT</translation>
    </message>
    <message>
        <location filename="../qml/pages/About.qml" line="91" />
        <source>Contributors</source>
        <translation>Contributeurs</translation>
    </message>
    <message>
        <location filename="../qml/pages/About.qml" line="110" />
        <source>Translations</source>
        <translation>Traductions</translation>
    </message>
    <message>
        <location filename="../qml/pages/About.qml" line="131" />
        <source>Thanks to</source>
        <translation>Remerciements</translation>
    </message>
</context>
<context>
    <name>Album</name>
    <message>
        <location filename="../qml/pages/Album.qml" line="56" />
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <location filename="../qml/pages/Album.qml" line="79" />
        <source>no artist known</source>
        <translation>artiste inconnu</translation>
    </message>
    <message>
        <location filename="../qml/pages/Album.qml" line="88" />
        <source>tracks</source>
        <translation>titres</translation>
    </message>
    <message>
        <location filename="../qml/pages/Album.qml" line="90" />
        <source>track</source>
        <translation>titre</translation>
    </message>
    <message>
        <location filename="../qml/pages/Album.qml" line="136" />
        <source>No Tracks found</source>
        <translation>Aucun titre trouvé</translation>
    </message>
</context>
<context>
    <name>AlbumTrackContextMenu</name>
    <message>
        <location filename="../qml/components/AlbumTrackContextMenu.qml" line="23" />
        <source>Play</source>
        <translation>Lire</translation>
    </message>
    <message>
        <location filename="../qml/components/AlbumTrackContextMenu.qml" line="28" />
        <source>View Album</source>
        <translation>Voir l'album</translation>
    </message>
    <message>
        <location filename="../qml/components/AlbumTrackContextMenu.qml" line="35" />
        <source>View Artist</source>
        <translation>Voir l'artiste</translation>
    </message>
    <message>
        <location filename="../qml/components/AlbumTrackContextMenu.qml" line="43" />
        <source>Add to Queue</source>
        <translation>Ajouter à la file d'attente</translation>
    </message>
    <message>
        <location filename="../qml/components/AlbumTrackContextMenu.qml" line="49" />
        <source>Replace Queue</source>
        <translation>Remplacer la file d'attente</translation>
    </message>
    <message>
        <location filename="../qml/components/AlbumTrackContextMenu.qml" line="54" />
        <source>Add to Playlist</source>
        <translation>Ajouter à une playlist</translation>
    </message>
</context>
<context>
    <name>AlbumTrackListItem</name>
    <message>
        <location filename="../qml/components/AlbumTrackListItem.qml" line="70" />
        <source>No Name</source>
        <translation>Sans nom</translation>
    </message>
</context>
<context>
    <name>Artist</name>
    <message>
        <location filename="../qml/pages/Artist.qml" line="46" />
        <source>Load Artist About Page in Browser</source>
        <translation>Ouvrir la page de l'artiste dans le navigateur</translation>
    </message>
    <message>
        <location filename="../qml/pages/Artist.qml" line="65" />
        <location filename="../qml/pages/Artist.qml" line="66" />
        <source>Artist </source>
        <translation>Artiste </translation>
    </message>
    <message>
        <location filename="../qml/pages/Artist.qml" line="65" />
        <source>Albums</source>
        <translation>Albums</translation>
    </message>
    <message>
        <location filename="../qml/pages/Artist.qml" line="66" />
        <source>Related Artists</source>
        <translation>Artistes similaires</translation>
    </message>
    <message>
        <location filename="../qml/pages/Artist.qml" line="93" />
        <source>No Name</source>
        <translation>Sans nom</translation>
    </message>
    <message>
        <location filename="../qml/pages/Artist.qml" line="106" />
        <source>followers</source>
        <translation>abonnés</translation>
    </message>
    <message>
        <location filename="../qml/pages/Artist.qml" line="151" />
        <source>No Artists found</source>
        <translation>Aucun artiste trouvé</translation>
    </message>
</context>
<context>
    <name>ArtistPicker</name>
    <message>
        <location filename="../qml/components/ArtistPicker.qml" line="38" />
        <source>Choose Artist</source>
        <translation>Choisir un artiste</translation>
    </message>
</context>
<context>
    <name>ConfirmDialog</name>
    <message>
        <location filename="../qml/components/ConfirmDialog.qml" line="20" />
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../qml/components/ConfirmDialog.qml" line="21" />
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
</context>
<context>
    <name>CoverPage</name>
    <message>
        <location filename="../qml/cover/CoverPage.qml" line="122" />
        <source>Nothing is playing</source>
        <translation>Aucune lecture en cours</translation>
    </message>
    <message>
        <location filename="../qml/cover/CoverPage.qml" line="128" />
        <source>Tap here to play something</source>
        <translation>Touchez ici pour lancer une lecture</translation>
    </message>
</context>
<context>
    <name>CreatePlaylist</name>
    <message>
        <location filename="../qml/components/CreatePlaylist.qml" line="13" />
        <source>Create Playlist</source>
        <translation>Créer la playlist</translation>
    </message>
    <message>
        <location filename="../qml/components/CreatePlaylist.qml" line="37" />
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../qml/components/CreatePlaylist.qml" line="38" />
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="../qml/components/CreatePlaylist.qml" line="53" />
        <source>Name for the new playlist</source>
        <translation>Nom de la nouvelle playlist</translation>
    </message>
    <message>
        <location filename="../qml/components/CreatePlaylist.qml" line="66" />
        <source>Public</source>
        <translation>Publique</translation>
    </message>
    <message>
        <location filename="../qml/components/CreatePlaylist.qml" line="77" />
        <source>Collaborative</source>
        <translation>Collaborative</translation>
    </message>
    <message>
        <location filename="../qml/components/CreatePlaylist.qml" line="83" />
        <source>Description (optional)</source>
        <translation>Description (facultative)</translation>
    </message>
</context>
<context>
    <name>Devices</name>
    <message>
        <location filename="../qml/pages/Devices.qml" line="37" />
        <source>Register Librespot Credentials</source>
        <translation>Enregistrer les identifiants Librespot</translation>
    </message>
    <message>
        <location filename="../qml/pages/Devices.qml" line="41" />
        <source>Reload Devices</source>
        <translation>Recharger les appareils</translation>
    </message>
    <message>
        <location filename="../qml/pages/Devices.qml" line="48" />
        <source>Stop Librespot</source>
        <translation>Arrêter Librespot</translation>
    </message>
    <message>
        <location filename="../qml/pages/Devices.qml" line="49" />
        <source>Start Librespot</source>
        <translation>Démarrer Librespot</translation>
    </message>
    <message>
        <location filename="../qml/pages/Devices.qml" line="61" />
        <source>Login</source>
        <translation>Connexion</translation>
    </message>
    <message>
        <location filename="../qml/pages/Devices.qml" line="65" />
        <source>Refresh Token</source>
        <translation>Renouveler l'autorisation</translation>
    </message>
    <message>
        <location filename="../qml/pages/Devices.qml" line="73" />
        <source>Devices</source>
        <translation>Appareils</translation>
    </message>
    <message>
        <location filename="../qml/pages/Devices.qml" line="117" />
        <source>Set as Current</source>
        <translation>Choisir comme appareil courant</translation>
    </message>
    <message>
        <location filename="../qml/pages/Devices.qml" line="129" />
        <source>Connect using Authorization Blob</source>
        <translation>Se connecter avec le jeton d'autorisation</translation>
    </message>
    <message>
        <location filename="../qml/pages/Devices.qml" line="149" />
        <source>Nothing Devices found</source>
        <translation>Aucun appareil trouvé</translation>
    </message>
    <message>
        <location filename="../qml/pages/Devices.qml" line="182" />
        <source>Unknown Name</source>
        <translation>Nom inconnu</translation>
    </message>
    <message>
        <location filename="../qml/pages/Devices.qml" line="200" />
        <source>active</source>
        <translation>actif</translation>
    </message>
    <message>
        <location filename="../qml/pages/Devices.qml" line="200" />
        <location filename="../qml/pages/Devices.qml" line="207" />
        <source>inactive</source>
        <translation>inactif</translation>
    </message>
    <message>
        <location filename="../qml/pages/Devices.qml" line="203" />
        <source>restricted</source>
        <translation>restreint</translation>
    </message>
    <message>
        <location filename="../qml/pages/Devices.qml" line="203" />
        <source>unrestricted</source>
        <translation>non restreint</translation>
    </message>
</context>
<context>
    <name>GenreMood</name>
    <message>
        <location filename="../qml/pages/GenreMood.qml" line="49" />
        <source>Genres &amp; Moods</source>
        <translation>Genres et ambiances</translation>
    </message>
    <message>
        <location filename="../qml/pages/GenreMood.qml" line="88" />
        <source>No Genres or Moods found</source>
        <translation>Aucun genre ni ambiance trouvé</translation>
    </message>
</context>
<context>
    <name>GenreMoodPlaylist</name>
    <message>
        <location filename="../qml/pages/GenreMoodPlaylist.qml" line="86" />
        <source>No Playlists found</source>
        <translation>Aucune playlist trouvée</translation>
    </message>
</context>
<context>
    <name>History</name>
    <message>
        <location filename="../qml/pages/History.qml" line="49" />
        <source>History</source>
        <translation>Historique</translation>
    </message>
    <message>
        <location filename="../qml/pages/History.qml" line="55" />
        <source>Clear History</source>
        <translation>Effacer l'historique</translation>
    </message>
    <message>
        <location filename="../qml/pages/History.qml" line="94" />
        <source>Nothing found</source>
        <translation>Aucun résultat</translation>
    </message>
</context>
<context>
    <name>Librespot</name>
    <message>
        <location filename="../qml/components/Librespot.qml" line="35" />
        <source>Librespot service stopped. Playing is paused.</source>
        <translation>Le service Librespot est arrêté. La lecture est en pause.</translation>
    </message>
    <message>
        <location filename="../qml/components/Librespot.qml" line="342" />
        <source>Librespot seems not available</source>
        <translation>Librespot semble indisponible</translation>
    </message>
    <message>
        <location filename="../qml/components/Librespot.qml" line="357" />
        <source>Failed to register credentials for Librespot</source>
        <translation>Échec de l'enregistrement des identifiants pour Librespot</translation>
    </message>
    <message>
        <location filename="../qml/components/Librespot.qml" line="359" />
        <source>Registered credentials for Librespot</source>
        <translation>Identifiants enregistrés pour Librespot</translation>
    </message>
    <message>
        <location filename="../qml/components/Librespot.qml" line="385" />
        <source>Enter Spotify credentials</source>
        <translation>Saisir vos identifiants Spotify</translation>
    </message>
    <message>
        <location filename="../qml/components/Librespot.qml" line="386" />
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../qml/components/Librespot.qml" line="387" />
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="../qml/components/Librespot.qml" line="393" />
        <source>Username</source>
        <translation>Nom d'utilisateur</translation>
    </message>
</context>
<context>
    <name>MultiItemPicker</name>
    <message>
        <location filename="../qml/components/MultiItemPicker.qml" line="34" />
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../qml/components/MultiItemPicker.qml" line="35" />
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
</context>
<context>
    <name>MyStuff</name>
    <message>
        <location filename="../qml/pages/MyStuff.qml" line="66" />
        <source>Reload</source>
        <translation>Recharger</translation>
    </message>
    <message>
        <location filename="../qml/pages/MyStuff.qml" line="86" />
        <source>My Library</source>
        <translation>Ma bibliothèque</translation>
    </message>
    <message>
        <location filename="../qml/pages/MyStuff.qml" line="93" />
        <source>Show</source>
        <translation>Afficher</translation>
    </message>
    <message>
        <location filename="../qml/pages/MyStuff.qml" line="96" />
        <source>Saved Albums</source>
        <translation>Albums enregistrés</translation>
    </message>
    <message>
        <location filename="../qml/pages/MyStuff.qml" line="97" />
        <source>Playlists</source>
        <translation>Playlists</translation>
    </message>
    <message>
        <location filename="../qml/pages/MyStuff.qml" line="98" />
        <source>Recently Played</source>
        <translation>Écoutés récemment</translation>
    </message>
    <message>
        <location filename="../qml/pages/MyStuff.qml" line="99" />
        <source>Saved Tracks</source>
        <translation>Titres enregistrés</translation>
    </message>
    <message>
        <location filename="../qml/pages/MyStuff.qml" line="100" />
        <source>Followed Artists</source>
        <translation>Artistes suivis</translation>
    </message>
    <message>
        <location filename="../qml/pages/MyStuff.qml" line="101" />
        <source>Podcasts</source>
        <translation>Podcasts</translation>
    </message>
    <message>
        <location filename="../qml/pages/MyStuff.qml" line="102" />
        <source>Audiobooks</source>
        <translation>Livres audio</translation>
    </message>
    <message>
        <location filename="../qml/pages/MyStuff.qml" line="114" />
        <source>Sort by</source>
        <translation>Trier par</translation>
    </message>
    <message>
        <location filename="../qml/pages/MyStuff.qml" line="117" />
        <source>Title</source>
        <translation>Titre</translation>
    </message>
    <message>
        <location filename="../qml/pages/MyStuff.qml" line="118" />
        <source>Artist</source>
        <translation>Artiste</translation>
    </message>
    <message>
        <location filename="../qml/pages/MyStuff.qml" line="119" />
        <source>Genre</source>
        <translation>Genre</translation>
    </message>
    <message>
        <location filename="../qml/pages/MyStuff.qml" line="120" />
        <source>Date added</source>
        <translation>Date d'ajout</translation>
    </message>
    <message>
        <location filename="../qml/pages/MyStuff.qml" line="162" />
        <source>Unfollow</source>
        <translation>Ne plus suivre</translation>
    </message>
    <message>
        <location filename="../qml/pages/MyStuff.qml" line="207" />
        <source>Nothing found</source>
        <translation>Aucun résultat</translation>
    </message>
    <message>
        <location filename="../qml/pages/MyStuff.qml" line="304" />
        <source>Unknown genre</source>
        <translation>Genre inconnu</translation>
    </message>
    <message>
        <location filename="../qml/pages/MyStuff.qml" line="330" />
        <location filename="../qml/pages/MyStuff.qml" line="338" />
        <source>Loading albums</source>
        <translation>Chargement des albums</translation>
    </message>
    <message>
        <location filename="../qml/pages/MyStuff.qml" line="361" />
        <source>Loading genres</source>
        <translation>Chargement des genres</translation>
    </message>
    <message>
        <location filename="../qml/pages/MyStuff.qml" line="547" />
        <source>Cannot load the library</source>
        <translation>Impossible de charger la bibliothèque</translation>
    </message>
</context>
<context>
    <name>NavigationMenu</name>
    <message>
        <location filename="../qml/pages/NavigationMenu.qml" line="32" />
        <source>My Stuff</source>
        <translation>Ma bibliothèque</translation>
    </message>
    <message>
        <location filename="../qml/pages/NavigationMenu.qml" line="36" />
        <source>Top Stuff</source>
        <translation>Mon top</translation>
    </message>
    <message>
        <location filename="../qml/pages/NavigationMenu.qml" line="41" />
        <source>History</source>
        <translation>Historique</translation>
    </message>
    <message>
        <location filename="../qml/pages/NavigationMenu.qml" line="46" />
        <source>Search</source>
        <translation>Recherche</translation>
    </message>
    <message>
        <location filename="../qml/pages/NavigationMenu.qml" line="50" />
        <source>Devices</source>
        <translation>Appareils</translation>
    </message>
    <message>
        <location filename="../qml/pages/NavigationMenu.qml" line="54" />
        <source>Settings</source>
        <translation>Réglages</translation>
    </message>
    <message>
        <location filename="../qml/pages/NavigationMenu.qml" line="58" />
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <location filename="../qml/pages/NavigationMenu.qml" line="62" />
        <source>About</source>
        <translation>À propos</translation>
    </message>
    <message>
        <location filename="../qml/pages/NavigationMenu.qml" line="77" />
        <source>Menu</source>
        <translation>Menu</translation>
    </message>
</context>
<context>
    <name>NavigationMenuDialog</name>
    <message>
        <location filename="../qml/components/NavigationMenuDialog.qml" line="27" />
        <source>Playing</source>
        <translation>Lecture en cours</translation>
    </message>
    <message>
        <location filename="../qml/components/NavigationMenuDialog.qml" line="32" />
        <source>My Stuff</source>
        <translation>Ma bibliothèque</translation>
    </message>
    <message>
        <location filename="../qml/components/NavigationMenuDialog.qml" line="36" />
        <source>Top Stuff</source>
        <translation>Mon top</translation>
    </message>
    <message>
        <location filename="../qml/components/NavigationMenuDialog.qml" line="41" />
        <source>History</source>
        <translation>Historique</translation>
    </message>
    <message>
        <location filename="../qml/components/NavigationMenuDialog.qml" line="46" />
        <source>Search</source>
        <translation>Recherche</translation>
    </message>
    <message>
        <location filename="../qml/components/NavigationMenuDialog.qml" line="50" />
        <source>Devices</source>
        <translation>Appareils</translation>
    </message>
    <message>
        <location filename="../qml/components/NavigationMenuDialog.qml" line="54" />
        <source>Settings</source>
        <translation>Réglages</translation>
    </message>
    <message>
        <location filename="../qml/components/NavigationMenuDialog.qml" line="58" />
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <location filename="../qml/components/NavigationMenuDialog.qml" line="62" />
        <source>About</source>
        <translation>À propos</translation>
    </message>
    <message>
        <location filename="../qml/components/NavigationMenuDialog.qml" line="76" />
        <source>Menu</source>
        <translation>Menu</translation>
    </message>
</context>
<context>
    <name>NavigationPullDown</name>
    <message>
        <location filename="../qml/components/NavigationPullDown.qml" line="24" />
        <source>About</source>
        <translation>À propos</translation>
    </message>
    <message>
        <location filename="../qml/components/NavigationPullDown.qml" line="28" />
        <source>Settings</source>
        <translation>Réglages</translation>
    </message>
    <message>
        <location filename="../qml/components/NavigationPullDown.qml" line="32" />
        <source>Devices</source>
        <translation>Appareils</translation>
    </message>
    <message>
        <location filename="../qml/components/NavigationPullDown.qml" line="37" />
        <source>History</source>
        <translation>Historique</translation>
    </message>
    <message>
        <location filename="../qml/components/NavigationPullDown.qml" line="42" />
        <source>My Top</source>
        <translation>Mon top</translation>
    </message>
    <message>
        <location filename="../qml/components/NavigationPullDown.qml" line="47" />
        <source>Search</source>
        <translation>Recherche</translation>
    </message>
    <message>
        <location filename="../qml/components/NavigationPullDown.qml" line="52" />
        <source>Featured</source>
        <translation>À la une</translation>
    </message>
    <message>
        <location filename="../qml/components/NavigationPullDown.qml" line="57" />
        <source>My Library</source>
        <translation>Ma bibliothèque</translation>
    </message>
    <message>
        <location filename="../qml/components/NavigationPullDown.qml" line="62" />
        <source>Now Playing</source>
        <translation>Lecture en cours</translation>
    </message>
</context>
<context>
    <name>NewAndFeatured</name>
    <message>
        <source>New Releases</source>
        <translation type="vanished">Nouveautés</translation>
    </message>
    <message>
        <location filename="../qml/pages/NewAndFeatured.qml" line="49" />
        <source>Reload</source>
        <translation>Recharger</translation>
    </message>
    <message>
        <location filename="../qml/pages/NewAndFeatured.qml" line="66" />
        <source>Featured</source>
        <translation>À la une</translation>
    </message>
    <message>
        <location filename="../qml/pages/NewAndFeatured.qml" line="117" />
        <source>Nothing found</source>
        <translation>Aucun résultat</translation>
    </message>
    <message>
        <location filename="../qml/pages/NewAndFeatured.qml" line="118" />
        <source>Pull down to reload</source>
        <translation>Tirez vers le bas pour recharger</translation>
    </message>
    <message>
        <location filename="../qml/pages/NewAndFeatured.qml" line="134" />
        <source>New from your artists</source>
        <translation>Nouveautés de vos artistes</translation>
    </message>
    <message>
        <location filename="../qml/pages/NewAndFeatured.qml" line="135" />
        <source>New on Spotify</source>
        <translation>Nouveautés sur Spotify</translation>
    </message>
    <message>
        <location filename="../qml/pages/NewAndFeatured.qml" line="136" />
        <source>Playlists for you</source>
        <translation>Playlists pour vous</translation>
    </message>
    <message>
        <location filename="../qml/pages/NewAndFeatured.qml" line="137" />
        <source>Your all-time favourites</source>
        <translation>Vos classiques</translation>
    </message>
    <message>
        <location filename="../qml/pages/NewAndFeatured.qml" line="242" />
        <source>Checking your artists</source>
        <translation>Vérification de vos artistes</translation>
    </message>
</context>
<context>
    <name>PlaybackState</name>
    <message>
        <source>Simple Spotify Controller</source>
        <translation type="vanished">Télécommande Spotify simple</translation>
    </message>
    <message>
        <location filename="../qml/components/PlaybackState.qml" line="103" />
        <source>no artist known</source>
        <translation>artiste inconnu</translation>
    </message>
</context>
<context>
    <name>Playing</name>
    <message>
        <location filename="../qml/pages/Playing.qml" line="23" />
        <source>Playing</source>
        <translation>Lecture en cours</translation>
    </message>
    <message>
        <location filename="../qml/pages/Playing.qml" line="63" />
        <location filename="../qml/pages/Playing.qml" line="75" />
        <source>Scroll to current Track</source>
        <translation>Aller au titre en cours</translation>
    </message>
    <message>
        <location filename="../qml/pages/Playing.qml" line="184" />
        <source>View Album</source>
        <translation>Voir l'album</translation>
    </message>
    <message>
        <location filename="../qml/pages/Playing.qml" line="200" />
        <source>View Artist</source>
        <translation>Voir l'artiste</translation>
    </message>
    <message>
        <location filename="../qml/pages/Playing.qml" line="218" />
        <source>View Playlist</source>
        <translation>Voir la playlist</translation>
    </message>
    <message>
        <location filename="../qml/pages/Playing.qml" line="510" />
        <location filename="../qml/pages/Playing.qml" line="529" />
        <source>no artist known</source>
        <translation>artiste inconnu</translation>
    </message>
    <message>
        <location filename="../qml/pages/Playing.qml" line="513" />
        <source>no genre known</source>
        <translation>genre inconnu</translation>
    </message>
    <message>
        <location filename="../qml/pages/Playing.qml" line="537" />
        <location filename="../qml/pages/Playing.qml" line="550" />
        <source>tracks</source>
        <translation>titres</translation>
    </message>
    <message>
        <location filename="../qml/pages/Playing.qml" line="539" />
        <source>track</source>
        <translation>titre</translation>
    </message>
    <message>
        <location filename="../qml/pages/Playing.qml" line="547" />
        <location filename="../qml/pages/Playing.qml" line="553" />
        <source>followers</source>
        <translation>abonnés</translation>
    </message>
    <message>
        <location filename="../qml/pages/Playing.qml" line="551" />
        <source>by</source>
        <translation>par</translation>
    </message>
    <message>
        <location filename="../qml/pages/Playing.qml" line="555" />
        <source>public</source>
        <translation>publique</translation>
    </message>
    <message>
        <location filename="../qml/pages/Playing.qml" line="557" />
        <source>collaborative</source>
        <translation>collaborative</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <location filename="../qml/pages/Playlist.qml" line="60" />
        <source>Playlist</source>
        <translation>Playlist</translation>
    </message>
    <message>
        <location filename="../qml/pages/Playlist.qml" line="126" />
        <source>Remove from Playlist</source>
        <translation>Retirer de la playlist</translation>
    </message>
    <message>
        <location filename="../qml/pages/Playlist.qml" line="138" />
        <source>Add to another Playlist</source>
        <translation>Ajouter à une autre playlist</translation>
    </message>
    <message>
        <location filename="../qml/pages/Playlist.qml" line="151" />
        <source>No tracks found</source>
        <translation>Aucun titre trouvé</translation>
    </message>
    <message>
        <location filename="../qml/pages/Playlist.qml" line="212" />
        <source>tracks</source>
        <translation>titres</translation>
    </message>
    <message>
        <location filename="../qml/pages/Playlist.qml" line="213" />
        <source>by</source>
        <translation>par</translation>
    </message>
    <message>
        <location filename="../qml/pages/Playlist.qml" line="215" />
        <source>followers</source>
        <translation>abonnés</translation>
    </message>
    <message>
        <location filename="../qml/pages/Playlist.qml" line="217" />
        <source>public</source>
        <translation>publique</translation>
    </message>
    <message>
        <location filename="../qml/pages/Playlist.qml" line="219" />
        <source>collaborative</source>
        <translation>collaborative</translation>
    </message>
    <message>
        <location filename="../qml/pages/Playlist.qml" line="272" />
        <source>Spotify no longer shows the tracks of playlists you do not own. Use the play button to listen to it.</source>
        <translation>Spotify n'affiche plus les titres des playlists dont vous n'êtes pas propriétaire. Utilisez le bouton de lecture pour l'écouter.</translation>
    </message>
</context>
<context>
    <name>PlaylistPicker</name>
    <message>
        <location filename="../qml/components/PlaylistPicker.qml" line="32" />
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../qml/components/PlaylistPicker.qml" line="33" />
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="../qml/components/PlaylistPicker.qml" line="73" />
        <source>Create New Playlist</source>
        <translation>Créer une nouvelle playlist</translation>
    </message>
</context>
<context>
    <name>QueueController</name>
    <message>
        <location filename="../qml/components/QueueController.qml" line="25" />
        <source>Playlist used as a queue by Hutspot</source>
        <translation>Playlist utilisée par Hutspot comme file d'attente</translation>
    </message>
    <message>
        <location filename="../qml/components/QueueController.qml" line="69" />
        <source>Hutspot wants to create playlist:&lt;br&gt;&lt;br&gt;&lt;b&gt;</source>
        <translation>Hutspot souhaite créer la playlist :&lt;br&gt;&lt;br&gt;&lt;b&gt;</translation>
    </message>
    <message>
        <location filename="../qml/components/QueueController.qml" line="70" />
        <source>which will be used as it's player queue. Is that Ok?</source>
        <translation>qui lui servira de file d'attente. Est-ce d'accord ?</translation>
    </message>
    <message>
        <location filename="../qml/components/QueueController.qml" line="154" />
        <source>Failed to add Track to the Queue</source>
        <translation>Impossible d'ajouter le titre à la file d'attente</translation>
    </message>
    <message>
        <location filename="../qml/components/QueueController.qml" line="159" />
        <location filename="../qml/components/QueueController.qml" line="188" />
        <source>Failed to find Playlist for Queue</source>
        <translation>Playlist de la file d'attente introuvable</translation>
    </message>
</context>
<context>
    <name>Recommended</name>
    <message>
        <location filename="../qml/pages/Recommended.qml" line="47" />
        <source>Reload</source>
        <translation>Recharger</translation>
    </message>
    <message>
        <location filename="../qml/pages/Recommended.qml" line="51" />
        <source>Play as Playlist</source>
        <translation>Lire comme une playlist</translation>
    </message>
    <message>
        <location filename="../qml/pages/Recommended.qml" line="70" />
        <location filename="../qml/pages/Recommended.qml" line="71" />
        <location filename="../qml/pages/Recommended.qml" line="72" />
        <location filename="../qml/pages/Recommended.qml" line="73" />
        <source>Recommended </source>
        <translation>Recommandés </translation>
    </message>
    <message>
        <location filename="../qml/pages/Recommended.qml" line="70" />
        <location filename="../qml/pages/Recommended.qml" line="92" />
        <source>Genres</source>
        <translation>Genres</translation>
    </message>
    <message>
        <location filename="../qml/pages/Recommended.qml" line="71" />
        <source>Genres+Attributes</source>
        <translation>Genres et critères</translation>
    </message>
    <message>
        <location filename="../qml/pages/Recommended.qml" line="72" />
        <source>Tracks</source>
        <translation>Titres</translation>
    </message>
    <message>
        <location filename="../qml/pages/Recommended.qml" line="73" />
        <source>Tracks+Attributes</source>
        <translation>Titres et critères</translation>
    </message>
    <message>
        <location filename="../qml/pages/Recommended.qml" line="110" />
        <location filename="../qml/pages/Recommended.qml" line="153" />
        <source>None</source>
        <translation>Aucun</translation>
    </message>
    <message>
        <location filename="../qml/pages/Recommended.qml" line="163" />
        <source>Spotify allows max. 5 seeds</source>
        <translation>Spotify accepte 5 critères au maximum</translation>
    </message>
    <message>
        <location filename="../qml/pages/Recommended.qml" line="179" />
        <source>Seed Tracks</source>
        <translation>Titres de départ</translation>
    </message>
    <message>
        <location filename="../qml/pages/Recommended.qml" line="203" />
        <source>Energy</source>
        <translation>Énergie</translation>
    </message>
    <message>
        <location filename="../qml/pages/Recommended.qml" line="214" />
        <source>Danceability</source>
        <translation>Dansant</translation>
    </message>
    <message>
        <location filename="../qml/pages/Recommended.qml" line="225" />
        <source>Instrumentalness</source>
        <translation>Instrumental</translation>
    </message>
    <message>
        <location filename="../qml/pages/Recommended.qml" line="236" />
        <source>Speechiness</source>
        <translation>Parlé</translation>
    </message>
    <message>
        <location filename="../qml/pages/Recommended.qml" line="247" />
        <source>Acousticness</source>
        <translation>Acoustique</translation>
    </message>
    <message>
        <location filename="../qml/pages/Recommended.qml" line="258" />
        <source>Liveness</source>
        <translation>En public</translation>
    </message>
    <message>
        <location filename="../qml/pages/Recommended.qml" line="269" />
        <source>Positiveness</source>
        <translation>Positivité</translation>
    </message>
    <message>
        <location filename="../qml/pages/Recommended.qml" line="280" />
        <source>Popularity</source>
        <translation>Popularité</translation>
    </message>
    <message>
        <location filename="../qml/pages/Recommended.qml" line="301" />
        <source>Recommended Tracks</source>
        <translation>Titres recommandés</translation>
    </message>
    <message>
        <location filename="../qml/pages/Recommended.qml" line="326" />
        <source>No Recommendations found</source>
        <translation>Aucune recommandation trouvée</translation>
    </message>
    <message>
        <location filename="../qml/pages/Recommended.qml" line="327" />
        <source>Enter Seeds/Attributes and Reload</source>
        <translation>Saisir les critères puis recharger</translation>
    </message>
</context>
<context>
    <name>Search</name>
    <message>
        <location filename="../qml/pages/Search.qml" line="25" />
        <location filename="../qml/pages/Search.qml" line="70" />
        <source>Albums</source>
        <translation>Albums</translation>
    </message>
    <message>
        <location filename="../qml/pages/Search.qml" line="25" />
        <location filename="../qml/pages/Search.qml" line="71" />
        <source>Artists</source>
        <translation>Artistes</translation>
    </message>
    <message>
        <location filename="../qml/pages/Search.qml" line="25" />
        <location filename="../qml/pages/Search.qml" line="72" />
        <source>Playlists</source>
        <translation>Playlists</translation>
    </message>
    <message>
        <location filename="../qml/pages/Search.qml" line="25" />
        <location filename="../qml/pages/Search.qml" line="73" />
        <source>Tracks</source>
        <translation>Titres</translation>
    </message>
    <message>
        <location filename="../qml/pages/Search.qml" line="61" />
        <source>Search</source>
        <translation>Recherche</translation>
    </message>
    <message>
        <location filename="../qml/pages/Search.qml" line="67" />
        <source>Search in</source>
        <translation>Rechercher parmi</translation>
    </message>
    <message>
        <location filename="../qml/pages/Search.qml" line="74" />
        <source>Podcasts</source>
        <translation>Podcasts</translation>
    </message>
    <message>
        <location filename="../qml/pages/Search.qml" line="75" />
        <source>Episodes</source>
        <translation>Épisodes</translation>
    </message>
    <message>
        <location filename="../qml/pages/Search.qml" line="76" />
        <source>Audiobooks</source>
        <translation>Livres audio</translation>
    </message>
    <message>
        <location filename="../qml/pages/Search.qml" line="90" />
        <source>Search text</source>
        <translation>Texte à rechercher</translation>
    </message>
    <message>
        <location filename="../qml/pages/Search.qml" line="115" />
        <source>Clear Current Text</source>
        <translation>Effacer le texte</translation>
    </message>
    <message>
        <location filename="../qml/pages/Search.qml" line="122" />
        <source>Select Recently Used Query</source>
        <translation>Choisir une recherche récente</translation>
    </message>
    <message>
        <location filename="../qml/pages/Search.qml" line="129" />
        <source>Search History</source>
        <translation>Historique de recherche</translation>
    </message>
    <message>
        <location filename="../qml/pages/Search.qml" line="143" />
        <source>Clear Recently Used Queries</source>
        <translation>Effacer les recherches récentes</translation>
    </message>
    <message>
        <location filename="../qml/pages/Search.qml" line="145" />
        <source>Please confirm Clearing the Search History</source>
        <translation>Confirmez-vous l'effacement de l'historique de recherche ?</translation>
    </message>
    <message>
        <location filename="../qml/pages/Search.qml" line="204" />
        <source>Nothing found</source>
        <translation>Aucun résultat</translation>
    </message>
    <message>
        <location filename="../qml/pages/Search.qml" line="359" />
        <source>Search Failed</source>
        <translation>Échec de la recherche</translation>
    </message>
</context>
<context>
    <name>SearchResultContextMenu</name>
    <message>
        <location filename="../qml/components/SearchResultContextMenu.qml" line="19" />
        <source>Play</source>
        <translation>Lire</translation>
    </message>
    <message>
        <location filename="../qml/components/SearchResultContextMenu.qml" line="55" />
        <source>Remove from Library</source>
        <translation>Retirer de la bibliothèque</translation>
    </message>
    <message>
        <location filename="../qml/components/SearchResultContextMenu.qml" line="55" />
        <source>Save to Library</source>
        <translation>Ajouter à la bibliothèque</translation>
    </message>
    <message>
        <location filename="../qml/components/SearchResultContextMenu.qml" line="59" />
        <source>View</source>
        <translation>Afficher</translation>
    </message>
    <message>
        <location filename="../qml/components/SearchResultContextMenu.qml" line="85" />
        <source>View Album</source>
        <translation>Voir l'album</translation>
    </message>
    <message>
        <location filename="../qml/components/SearchResultContextMenu.qml" line="92" />
        <source>Add to Playlist</source>
        <translation>Ajouter à une playlist</translation>
    </message>
    <message>
        <location filename="../qml/components/SearchResultContextMenu.qml" line="98" />
        <source>Use as Seeds for Recommendations</source>
        <translation>Utiliser pour les recommandations</translation>
    </message>
</context>
<context>
    <name>SearchResultListItem</name>
    <message>
        <location filename="../qml/components/SearchResultListItem.qml" line="60" />
        <source>No Name</source>
        <translation>Sans nom</translation>
    </message>
    <message>
        <location filename="../qml/components/SearchResultListItem.qml" line="163" />
        <location filename="../qml/components/SearchResultListItem.qml" line="198" />
        <source>no artist known</source>
        <translation>artiste inconnu</translation>
    </message>
    <message>
        <location filename="../qml/components/SearchResultListItem.qml" line="168" />
        <source>no genre known</source>
        <translation>genre inconnu</translation>
    </message>
    <message>
        <location filename="../qml/components/SearchResultListItem.qml" line="174" />
        <source>Id</source>
        <translation>Identifiant</translation>
    </message>
    <message>
        <location filename="../qml/components/SearchResultListItem.qml" line="180" />
        <source>Podcast</source>
        <translation>Podcast</translation>
    </message>
    <message>
        <location filename="../qml/components/SearchResultListItem.qml" line="186" />
        <source>read by</source>
        <translation>lu par</translation>
    </message>
    <message>
        <location filename="../qml/components/SearchResultListItem.qml" line="201" />
        <source>album not specified</source>
        <translation>album non précisé</translation>
    </message>
    <message>
        <location filename="../qml/components/SearchResultListItem.qml" line="222" />
        <source>followers</source>
        <translation>abonnés</translation>
    </message>
    <message>
        <location filename="../qml/components/SearchResultListItem.qml" line="229" />
        <source>episodes</source>
        <translation>épisodes</translation>
    </message>
    <message>
        <location filename="../qml/components/SearchResultListItem.qml" line="233" />
        <source>chapters</source>
        <translation>chapitres</translation>
    </message>
    <message>
        <location filename="../qml/components/SearchResultListItem.qml" line="241" />
        <source>played</source>
        <translation>écouté</translation>
    </message>
    <message>
        <location filename="../qml/components/SearchResultListItem.qml" line="243" />
        <source>in progress</source>
        <translation>en cours</translation>
    </message>
    <message>
        <location filename="../qml/components/SearchResultListItem.qml" line="250" />
        <source>played at </source>
        <translation>écouté le </translation>
    </message>
    <message>
        <location filename="../qml/components/SearchResultListItem.qml" line="258" />
        <source>track</source>
        <translation>titre</translation>
    </message>
    <message>
        <location filename="../qml/components/SearchResultListItem.qml" line="258" />
        <source>tracks</source>
        <translation>titres</translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <location filename="../qml/pages/Settings.qml" line="25" />
        <source>Register Librespot Credentials</source>
        <translation>Enregistrer les identifiants Librespot</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="32" />
        <source>Login</source>
        <translation>Connexion</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="36" />
        <source>Refresh Token</source>
        <translation>Renouveler l'autorisation</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="47" />
        <source>Settings</source>
        <translation>Réglages</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="51" />
        <source>Hutspot</source>
        <translation>Hutspot</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="55" />
        <source>Number of results per request (limit)</source>
        <translation>Nombre de résultats par requête (10 au maximum)</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="64" />
        <source>Maximum size of Search History</source>
        <translation>Taille maximale de l'historique de recherche</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="73" />
        <source>Enable Device Discovery</source>
        <translation>Activer la recherche des appareils</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="74" />
        <source>Discover Spotify Connect Devices on your network.</source>
        <translation>Rechercher les appareils Spotify Connect sur votre réseau.</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="88" />
        <source>Control Librespot</source>
        <translation>Piloter Librespot</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="89" />
        <source>Start Librespot when launched and stop it on exit</source>
        <translation>Démarrer Librespot à l'ouverture et l'arrêter à la fermeture</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="101" />
        <source>Cannot start Librespot</source>
        <translation>Impossible de démarrer Librespot</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="104" />
        <source>Stop Librespot</source>
        <translation>Arrêter Librespot</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="105" />
        <source>Start Librespot</source>
        <translation>Démarrer Librespot</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="109" />
        <source>Librespot is not available</source>
        <translation>Librespot n'est pas disponible</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="112" />
        <source>Running</source>
        <translation>En marche</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="113" />
        <source>Not Running</source>
        <translation>Arrêté</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="128" />
        <source>Show Devices page at startup</source>
        <translation>Afficher les appareils au démarrage</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="129" />
        <source>So you can watch the devices become available</source>
        <translation>Pour voir les appareils apparaître</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="139" />
        <source>Hutspot Queue Playlist name</source>
        <translation>Nom de la playlist servant de file d'attente</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="150" />
        <source>Country Code (2 characters)</source>
        <translation>Code pays (2 lettres)</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="162" />
        <source>Query for Market</source>
        <translation>Filtrer selon le pays</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="163" />
        <source>Show only content playable in the country associated with the user account</source>
        <translation>Ne montrer que les contenus disponibles dans le pays de votre compte</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="176" />
        <source>ControlPanel Show Delay</source>
        <translation>Délai d'affichage du mini-lecteur</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="183" />
        <source>Confirm Un-Save/Follow</source>
        <translation>Confirmer le retrait des favoris</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="184" />
        <source>Ask for confirmation for un-save and un-follow</source>
        <translation>Demander confirmation avant de retirer un favori ou de ne plus suivre</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="197" />
        <source>Navigation Menu Type</source>
        <translation>Type de menu de navigation</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="200" />
        <source>Page with List of Menu Items</source>
        <translation>Page avec la liste des menus</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="201" />
        <source>Menu Page attached to Playing Page</source>
        <translation>Page de menu à côté de la lecture en cours</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="202" />
        <source>Docked Panel with all Icons</source>
        <translation>Panneau du bas avec toutes les icônes</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="203" />
        <source>Docked Panel with Player Controls and Hamburger button</source>
        <translation>Panneau du bas avec commandes de lecture et menu</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="216" />
        <source>Playing as Attached Page</source>
        <translation>Lecture en cours à droite</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="217" />
        <source>Have the Playing page as an Attached Page (available on the Right)</source>
        <translation>Placer la page « Lecture en cours » à droite de chaque page</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="238" />
        <source>Authorize using Browser</source>
        <translation>S'autoriser avec le navigateur</translation>
    </message>
    <message>
        <location filename="../qml/pages/Settings.qml" line="239" />
        <source>Use external Browser to login at Spotify</source>
        <translation>Se connecter à Spotify avec le navigateur</translation>
    </message>
</context>
<context>
    <name>Show</name>
    <message>
        <location filename="../qml/pages/Show.qml" line="44" />
        <source>Remove from Library</source>
        <translation>Retirer de la bibliothèque</translation>
    </message>
    <message>
        <location filename="../qml/pages/Show.qml" line="44" />
        <source>Save to Library</source>
        <translation>Ajouter à la bibliothèque</translation>
    </message>
    <message>
        <location filename="../qml/pages/Show.qml" line="48" />
        <source>Play the Audiobook</source>
        <translation>Écouter le livre audio</translation>
    </message>
    <message>
        <location filename="../qml/pages/Show.qml" line="48" />
        <source>Play the Podcast</source>
        <translation>Écouter le podcast</translation>
    </message>
    <message>
        <location filename="../qml/pages/Show.qml" line="61" />
        <source>Audiobook</source>
        <translation>Livre audio</translation>
    </message>
    <message>
        <location filename="../qml/pages/Show.qml" line="61" />
        <source>Podcast</source>
        <translation>Podcast</translation>
    </message>
    <message>
        <location filename="../qml/pages/Show.qml" line="105" />
        <source>chapters</source>
        <translation>chapitres</translation>
    </message>
    <message>
        <location filename="../qml/pages/Show.qml" line="106" />
        <source>episodes</source>
        <translation>épisodes</translation>
    </message>
    <message>
        <location filename="../qml/pages/Show.qml" line="110" />
        <source>Play</source>
        <translation>Lire</translation>
    </message>
    <message>
        <location filename="../qml/pages/Show.qml" line="136" />
        <source>Chapters</source>
        <translation>Chapitres</translation>
    </message>
    <message>
        <location filename="../qml/pages/Show.qml" line="136" />
        <source>Episodes</source>
        <translation>Épisodes</translation>
    </message>
    <message>
        <location filename="../qml/pages/Show.qml" line="155" />
        <source>No chapters found</source>
        <translation>Aucun chapitre trouvé</translation>
    </message>
    <message>
        <location filename="../qml/pages/Show.qml" line="155" />
        <source>No episodes found</source>
        <translation>Aucun épisode trouvé</translation>
    </message>
    <message>
        <location filename="../qml/pages/Show.qml" line="197" />
        <source>Cannot load the chapters</source>
        <translation>Impossible de charger les chapitres</translation>
    </message>
    <message>
        <location filename="../qml/pages/Show.qml" line="198" />
        <source>Cannot load the episodes</source>
        <translation>Impossible de charger les épisodes</translation>
    </message>
    <message>
        <location filename="../qml/pages/Show.qml" line="224" />
        <source>Play Failed</source>
        <translation>Échec de la lecture</translation>
    </message>
    <message>
        <location filename="../qml/pages/Show.qml" line="233" />
        <source>Failed</source>
        <translation>Échec</translation>
    </message>
</context>
<context>
    <name>SoloistSettings</name>
    <message>
        <location filename="../qml/components/SoloistSettings.qml" line="26" />
        <source>Player on the phone (Soloist)</source>
        <translation>Lecteur du téléphone (Soloist)</translation>
    </message>
    <message>
        <location filename="../qml/components/SoloistSettings.qml" line="36" />
        <source>Connected to your Spotify account</source>
        <translation>Connecté à votre compte Spotify</translation>
    </message>
    <message>
        <location filename="../qml/components/SoloistSettings.qml" line="37" />
        <source>Not paired: use Pair again</source>
        <translation>Non appairé : utilisez « Réappairer »</translation>
    </message>
    <message>
        <location filename="../qml/components/SoloistSettings.qml" line="38" />
        <source>Soloist is not running</source>
        <translation>Soloist n'est pas lancé</translation>
    </message>
    <message>
        <location filename="../qml/components/SoloistSettings.qml" line="40" />
        <source>Checking…</source>
        <translation>Vérification…</translation>
    </message>
    <message>
        <location filename="../qml/components/SoloistSettings.qml" line="63" />
        <source>Pair again</source>
        <translation>Réappairer</translation>
    </message>
    <message>
        <location filename="../qml/components/SoloistSettings.qml" line="66" />
        <source>Starting…</source>
        <translation>Démarrage…</translation>
    </message>
    <message>
        <location filename="../qml/components/SoloistSettings.qml" line="77" />
        <source>Needed after a new key or if the phone no longer appears in Spotify. Then choose the phone in a Spotify app (computer, other phone) on the same Wi-Fi.</source>
        <translation>Nécessaire après une nouvelle clé, ou si le téléphone n'apparaît plus dans Spotify. Choisissez ensuite le téléphone dans une application Spotify (ordinateur, autre téléphone) connectée au même Wi-Fi.</translation>
    </message>
    <message>
        <location filename="../qml/components/SoloistSettings.qml" line="83" />
        <source>New Soloist key</source>
        <translation>Nouvelle clé Soloist</translation>
    </message>
    <message>
        <location filename="../qml/components/SoloistSettings.qml" line="84" />
        <source>New Soloist key (spak_…)</source>
        <translation>Nouvelle clé Soloist (spak_…)</translation>
    </message>
    <message>
        <location filename="../qml/components/SoloistSettings.qml" line="93" />
        <source>Save the key</source>
        <translation>Enregistrer la clé</translation>
    </message>
    <message>
        <location filename="../qml/components/SoloistSettings.qml" line="101" />
        <source>Saving the key and restarting Soloist…</source>
        <translation>Enregistrement de la clé et redémarrage de Soloist…</translation>
    </message>
    <message>
        <location filename="../qml/components/SoloistSettings.qml" line="131" />
        <source>Choose “%1” in a Spotify app on the same Wi-Fi (3 minutes).</source>
        <translation>Choisissez « %1 » dans une application Spotify connectée au même Wi-Fi (3 minutes).</translation>
    </message>
    <message>
        <location filename="../qml/components/SoloistSettings.qml" line="142" />
        <source>Paired. Soloist is connected.</source>
        <translation>Appairage réussi. Soloist est connecté.</translation>
    </message>
    <message>
        <location filename="../qml/components/SoloistSettings.qml" line="143" />
        <source>No Spotify app chose the phone in time.</source>
        <translation>Aucune application Spotify n'a choisi le téléphone à temps.</translation>
    </message>
    <message>
        <location filename="../qml/components/SoloistSettings.qml" line="144" />
        <source>Save a Soloist key first.</source>
        <translation>Enregistrez d'abord une clé Soloist.</translation>
    </message>
    <message>
        <location filename="../qml/components/SoloistSettings.qml" line="145" />
        <source>Soloist could not be started.</source>
        <translation>Soloist n'a pas pu être lancé.</translation>
    </message>
    <message>
        <location filename="../qml/components/SoloistSettings.qml" line="146" />
        <source>Key saved. Soloist is connected.</source>
        <translation>Clé enregistrée. Soloist est connecté.</translation>
    </message>
    <message>
        <location filename="../qml/components/SoloistSettings.qml" line="147" />
        <source>Key saved. Now pair the phone again.</source>
        <translation>Clé enregistrée. Réappairez maintenant le téléphone.</translation>
    </message>
    <message>
        <location filename="../qml/components/SoloistSettings.qml" line="148" />
        <source>This is not a Soloist key (it starts with spak_).</source>
        <translation>Ce n'est pas une clé Soloist (elle commence par spak_).</translation>
    </message>
    <message>
        <location filename="../qml/components/SoloistSettings.qml" line="149" />
        <source>Key saved, but Soloist did not restart.</source>
        <translation>Clé enregistrée, mais Soloist n'a pas redémarré.</translation>
    </message>
</context>
<context>
    <name>SpotifyController</name>
    <message>
        <location filename="../qml/components/SpotifyController.qml" line="337" />
        <location filename="../qml/components/SpotifyController.qml" line="350" />
        <source>Play Failed</source>
        <translation>Échec de la lecture</translation>
    </message>
    <message>
        <location filename="../qml/components/SpotifyController.qml" line="368" />
        <source>Play failed</source>
        <translation>Échec de la lecture</translation>
    </message>
    <message>
        <location filename="../qml/components/SpotifyController.qml" line="373" />
        <source>No device selected</source>
        <translation>Aucun appareil choisi</translation>
    </message>
</context>
<context>
    <name>TopStuff</name>
    <message>
        <location filename="../qml/pages/TopStuff.qml" line="55" />
        <source>My Top</source>
        <translation>Mon top</translation>
    </message>
    <message>
        <location filename="../qml/pages/TopStuff.qml" line="61" />
        <source>Show</source>
        <translation>Afficher</translation>
    </message>
    <message>
        <location filename="../qml/pages/TopStuff.qml" line="64" />
        <source>Top Tracks</source>
        <translation>Titres préférés</translation>
    </message>
    <message>
        <location filename="../qml/pages/TopStuff.qml" line="65" />
        <source>Top Artists</source>
        <translation>Artistes préférés</translation>
    </message>
    <message>
        <location filename="../qml/pages/TopStuff.qml" line="107" />
        <source>Nothing found</source>
        <translation>Aucun résultat</translation>
    </message>
</context>
<context>
    <name>WebAuth</name>
    <message>
        <location filename="../qml/components/WebAuth.qml" line="17" />
        <source>Authorization</source>
        <translation>Autorisation</translation>
    </message>
</context>
<context>
    <name>hutspot</name>
    <message>
        <location filename="../qml/hutspot.qml" line="95" />
        <source>connecting</source>
        <translation>connexion…</translation>
    </message>
    <message>
        <location filename="../qml/hutspot.qml" line="366" />
        <source>Spotify error</source>
        <translation>Erreur Spotify</translation>
    </message>
    <message>
        <location filename="../qml/hutspot.qml" line="369" />
        <source>Cannot reach Spotify: check the connection</source>
        <translation>Spotify injoignable : vérifiez la connexion</translation>
    </message>
    <message>
        <location filename="../qml/hutspot.qml" line="383" />
        <source>Spotify asks you to log in again (Settings, Login)</source>
        <translation>Spotify demande une nouvelle connexion (Réglages, Connexion)</translation>
    </message>
    <message>
        <location filename="../qml/hutspot.qml" line="392" />
        <source>Failed to transfer to</source>
        <translation>Échec du transfert vers</translation>
    </message>
    <message>
        <location filename="../qml/hutspot.qml" line="509" />
        <source>Disconnected</source>
        <translation>Déconnecté</translation>
    </message>
    <message>
        <location filename="../qml/hutspot.qml" line="521" />
        <source>Connected</source>
        <translation>Connecté</translation>
    </message>
    <message>
        <location filename="../qml/hutspot.qml" line="711" />
        <source>Edit Playlist Details</source>
        <translation>Modifier la playlist</translation>
    </message>
    <message>
        <location filename="../qml/hutspot.qml" line="738" />
        <source>Select a Playlist</source>
        <translation>Choisir une playlist</translation>
    </message>
    <message>
        <location filename="../qml/hutspot.qml" line="985" />
        <source>Failed</source>
        <translation>Échec</translation>
    </message>
    <message>
        <location filename="../qml/hutspot.qml" line="993" />
        <source>Added to your library</source>
        <translation>Ajouté à votre bibliothèque</translation>
    </message>
    <message>
        <location filename="../qml/hutspot.qml" line="994" />
        <source>Removed from your library</source>
        <translation>Retiré de votre bibliothèque</translation>
    </message>
    <message>
        <location filename="../qml/hutspot.qml" line="1002" />
        <source>Remove from your library?</source>
        <translation>Retirer de votre bibliothèque ?</translation>
    </message>
    <message>
        <location filename="../qml/hutspot.qml" line="1063" />
        <source>View an Artist</source>
        <translation>Voir un artiste</translation>
    </message>
</context>
</TS>