/*
 * libforcerole 1.0.0
 *
 * Bibliothèque chargée avant Soloist (LD_PRELOAD). Elle remplace le rôle
 * « music » que Soloist donne à son flux sonore par le rôle « x-maemo »,
 * celui des applications natives de Sailfish OS. Les boutons de volume du
 * téléphone n'agissent que sur les flux qui portent ce rôle.
 *
 * Le rôle voulu peut être changé avec la variable FORCE_MEDIA_ROLE.
 *
 * Compilation :
 *   gcc -O2 -shared -fPIC -o libforcerole.so forcerole.c -ldl
 */
#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdlib.h>
#include <string.h>

typedef struct pa_proplist pa_proplist;
typedef struct pa_context pa_context;
typedef struct pa_stream pa_stream;
typedef struct pa_sample_spec pa_sample_spec;
typedef struct pa_channel_map pa_channel_map;

static const char *role(void)
{
    const char *r = getenv("FORCE_MEDIA_ROLE");
    return (r && *r) ? r : "x-maemo";
}

int pa_proplist_sets(pa_proplist *p, const char *key, const char *value)
{
    static int (*real)(pa_proplist *, const char *, const char *);
    if (!real)
        real = dlsym(RTLD_NEXT, "pa_proplist_sets");
    if (key && strcmp(key, "media.role") == 0)
        value = role();
    return real(p, key, value);
}

pa_stream *pa_stream_new_with_proplist(pa_context *c, const char *name,
                                       const pa_sample_spec *ss,
                                       const pa_channel_map *map,
                                       pa_proplist *p)
{
    static pa_stream *(*real)(pa_context *, const char *, const pa_sample_spec *,
                              const pa_channel_map *, pa_proplist *);
    if (!real)
        real = dlsym(RTLD_NEXT, "pa_stream_new_with_proplist");
    if (p)
        pa_proplist_sets(p, "media.role", role());
    return real(c, name, ss, map, p);
}
